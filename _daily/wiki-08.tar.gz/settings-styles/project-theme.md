---
title: App Theme
description: 
published: true
date: 2021-08-18T00:37:48.497Z
tags: 
editor: markdown
dateCreated: 2021-08-16T04:11:25.565Z
---

# App Theme
RadSystems have many themes of choices, it's just a click away.
![menubar.png](/settings-style/theme/menubar.png)
## PhpRad Classic
![classic.png](/settings-style/theme/classic.png)
1. Click **Project Theme**.
2. You can just choose a template you like in **Select Template** dropdown.
3. **Navbar Variant** - This is a background color of the navigation bar
- Primary
- Secondary
- Light
- Dark
- White
- Danger
- Success
- Info
- Warning

3. **Light Text Color** - Its a text color associated with the navbar viriant 


## PhpRad, NodeRad, ASPRad, PyRad
Unlike in PHPClassic. PhpRad, NodeRad, ASPRad and PyRad uses Quasar framework and it is more flexible as you can define your own color and layouts for its components.

![1.png](/settings-style/theme/1.png)

1. Click **Projec Theme**
2. Set **Layout**

3. Theme

4. Header

5. Footer

6. LeftDrawer

7. RightDrawer

8. InputField

9. Button

10. Card


> Note: You can check online for color generator, e.g https://htmlcolorcodes.com/
{.is-info}
